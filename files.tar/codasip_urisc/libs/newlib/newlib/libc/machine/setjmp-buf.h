#ifndef SETJMP_BUF_H_
#define SETJMP_BUF_H_

// jump buffer to store 32 registers
#define SETJMP_BUF int jmp_buf[32];

#endif // SETJMP_BUF_H_
