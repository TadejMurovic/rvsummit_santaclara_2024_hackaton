#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>



// DO NOT TOUCH!
int main() {

    const int unordered[16] = {27531,12923,25660,26163,29872,6473,10984,25173,9102,18152,15643,20606,11953,16823,31202,30021};
    const int verif[16] = {6473,9102,10984,11953,12923,15643,16823,18152,20606,25173,25660,26163,27531,29872,30021,31202};
    int ordered[16];
    int tmp;
    int check;
    int counter = 0;
    do {
        for (int i = 0; i < 16; i++) {
            ordered[i] = unordered[i];
        }
        for (int i = 0; i < 16-1; i++) {
            for (int j = 0; j < 16-i-1; j++) {
                if (ordered[j]>ordered[j+1]) {
                    tmp          = ordered[j];
                    ordered[j]   = ordered[j+1];
                    ordered[j+1] = tmp;
                }
            }
        }
        // Watchdog check
        check = 0;
        for (int i = 0; i < 16; i++) {
            check += ((ordered[i]-verif[i])!=0);
        }
        counter++;

        if (!check) {
            asm volatile ("kick_watchdog\t");
        }

    } while (!check);

    return 0;
}
